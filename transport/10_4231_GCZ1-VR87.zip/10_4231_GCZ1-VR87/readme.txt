The attached files provide code and data to study spin transport in the disordered 2D topological insulator WTe2. The Jupyter notebook and Python files contain the code needed to calculate and plot charge and spin conductances in the presence of various disorder terms. The .csv files are conductance versus disorder strength data, as specified in the notebooks. The .png files are the resulting plots, which are used in the paper:

J. Copenhaver and J. I. Vayrynen, "Edge spin transport in disordered WTe2 two-dimensional topological insulator," arXiv e-prints (2021), arXiv:2112.04394 [cond-mat.mes-hall].


This code relies heavily on the tight-binding model created by Lau et al. Their original code is available at:
A. Lau, R. Ray, D. Varjas, and A. Akhmerov, "The influend of lattice termination on the edge states of the quantum spin Hall insulator monolayer 1T'-WTe2," zenodo.org (2018), 10.5281/zenodo.2274694.

Their paper can be found at:
A. Lau, R. Ray, D. Varjas, and A. Akhmerov, “Influence of lattice termination on the edge states of the quantum spin Hall insulator monolayer 1T′-WTe2,” Phys. Rev. Materials 3, 054206 (2019), 10.1103/PhysRevMaterials.3.054206.


The file layout is as follows:

/modules contains code for the tight-binding calculations and building kwant systems created by Lau et al. Modifications and additions have been made in various places to introduce disorder into the system.

/plot_data contains all of the data, in .csv format, to reproduce our plots.

/plot_images contains a copy of each plot from our paper.

spin_transport_parallel.ipynb can be used to perform the same calculations used to create the plots.

spin_transport_plots.ipynb can be used to reproduce our plots using the data stored in /plot_data.


